"""
lookback_core.py — shared data / model / training logic for the Lookback
LSTM & GRU stock predictor. Used by app.py (the Streamlit website) and can
also be imported from a notebook or another script.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset


# --------------------------------------------------------------------------
# Data loading
# --------------------------------------------------------------------------

def generate_synthetic_series(n: int = 500, seed: Optional[int] = None) -> pd.DataFrame:
    """A geometric-Brownian-motion-ish random walk, for trying the app with
    no upload and no network."""
    rng = np.random.default_rng(seed)
    price = 100 + rng.random() * 50
    drift, vol = 0.0003, 0.014
    closes = np.empty(n)
    for i in range(n):
        shock = rng.standard_normal()
        price *= (1 + drift + vol * shock)
        closes[i] = price
    dates = pd.bdate_range(end=pd.Timestamp.today(), periods=n)
    return pd.DataFrame({"Close": closes}, index=dates)


def load_from_csv(file_or_path) -> pd.DataFrame:
    """Accepts a path string or a file-like object (e.g. Streamlit's
    UploadedFile). Expects a Date column and a Close or Adj Close column."""
    df = pd.read_csv(file_or_path)
    df.columns = [c.strip() for c in df.columns]
    date_col = next((c for c in df.columns if c.lower() == "date"), df.columns[0])
    close_col = next((c for c in df.columns if c.lower() == "adj close"), None)
    if close_col is None:
        close_col = next((c for c in df.columns if c.lower() == "close"), None)
    if close_col is None:
        raise ValueError(
            f"Couldn't find a 'Close' or 'Adj Close' column. Columns found: {list(df.columns)}"
        )
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
    df = df.dropna(subset=[date_col, close_col]).sort_values(date_col)
    df = df.set_index(date_col)[[close_col]].rename(columns={close_col: "Close"})
    df["Close"] = pd.to_numeric(df["Close"], errors="coerce")
    return df.dropna()


def load_from_yfinance(ticker: str, period: str = "3y") -> pd.DataFrame:
    import yfinance as yf
    df = yf.download(ticker, period=period, progress=False, auto_adjust=True)
    if df.empty:
        raise ValueError(f"yfinance returned no data for ticker '{ticker}'.")
    df = df[["Close"]].copy()
    df.columns = ["Close"]
    return df


# --------------------------------------------------------------------------
# Windowing and scaling
# --------------------------------------------------------------------------

def minmax_fit(values: np.ndarray) -> tuple[float, float]:
    return float(values.min()), float(values.max())


def minmax_transform(values: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    span = (vmax - vmin) or 1.0
    return (values - vmin) / span


def minmax_inverse(values: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    return values * (vmax - vmin) + vmin


def make_sequences(series: np.ndarray, lookback: int) -> tuple[np.ndarray, np.ndarray]:
    """Slide a window of length `lookback` across `series`, predicting the
    single next value each time."""
    X, y = [], []
    for i in range(len(series) - lookback):
        X.append(series[i:i + lookback])
        y.append(series[i + lookback])
    return np.array(X), np.array(y)


# --------------------------------------------------------------------------
# Model
# --------------------------------------------------------------------------

class SequenceRegressor(nn.Module):
    """A single recurrent stack (LSTM or GRU) followed by a linear head that
    predicts the next closing price from the final hidden state."""

    def __init__(self, cell: str, hidden_size: int, num_layers: int, dropout: float = 0.0):
        super().__init__()
        rnn_cls = nn.LSTM if cell == "lstm" else nn.GRU
        self.rnn = rnn_cls(
            input_size=1,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.rnn(x)          # x: (batch, lookback, 1)
        last_step = out[:, -1, :]
        return self.head(last_step)


# --------------------------------------------------------------------------
# Training / evaluation
# --------------------------------------------------------------------------

def train_model(model: nn.Module, X_train, y_train, epochs: int, batch_size: int,
                 lr: float, device: torch.device, on_epoch_end=None) -> list[float]:
    """Trains in place. If `on_epoch_end(epoch, epochs, loss)` is given, it's
    called after every epoch — the Streamlit app uses this to update a live
    loss chart and progress bar."""
    model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    dataset = TensorDataset(
        torch.tensor(X_train, dtype=torch.float32).unsqueeze(-1),
        torch.tensor(y_train, dtype=torch.float32).unsqueeze(-1),
    )
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    history = []
    model.train()
    for epoch in range(1, epochs + 1):
        running = 0.0
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            pred = model(xb)
            loss = loss_fn(pred, yb)
            loss.backward()
            optimizer.step()
            running += loss.item() * xb.size(0)
        epoch_loss = running / len(dataset)
        history.append(epoch_loss)
        if on_epoch_end is not None:
            on_epoch_end(epoch, epochs, epoch_loss)
    return history


@torch.no_grad()
def predict(model: nn.Module, X: np.ndarray, device: torch.device) -> np.ndarray:
    model.eval()
    xb = torch.tensor(X, dtype=torch.float32).unsqueeze(-1).to(device)
    return model(xb).cpu().numpy().reshape(-1)


def compute_metrics(actual: np.ndarray, pred: np.ndarray, prev_actual: np.ndarray) -> dict:
    err = actual - pred
    rmse = float(np.sqrt(np.mean(err ** 2)))
    mae = float(np.mean(np.abs(err)))
    mape = float(np.mean(np.abs(err / np.where(actual == 0, 1, actual))) * 100)
    actual_dir = np.sign(actual - prev_actual)
    pred_dir = np.sign(pred - prev_actual)
    dir_acc = float(np.mean(actual_dir == pred_dir) * 100)
    return {"rmse": rmse, "mae": mae, "mape": mape, "directional_accuracy": dir_acc}


@torch.no_grad()
def forecast_forward(model: nn.Module, last_window: np.ndarray, steps: int,
                      device: torch.device) -> np.ndarray:
    """Recursive multi-step forecast: predict one step, slide it into the
    window, predict the next, and so on."""
    model.eval()
    window = last_window.copy()
    preds = []
    for _ in range(steps):
        xb = torch.tensor(window, dtype=torch.float32).reshape(1, -1, 1).to(device)
        next_val = model(xb).cpu().numpy().reshape(-1)[0]
        preds.append(next_val)
        window = np.append(window[1:], next_val)
    return np.array(preds)
