"""
app.py — Lookback, an LSTM/GRU stock predictor as a Streamlit website.

Run it with:
    streamlit run app.py
"""

from __future__ import annotations

import time

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import torch

import lookback_core as lb

# --------------------------------------------------------------------------
# Page setup + theme
# --------------------------------------------------------------------------

st.set_page_config(page_title="Lookback — LSTM/GRU stock predictor", page_icon="📈", layout="wide")

INK = "#0D1117"
PANEL = "#141B26"
LINE = "#2A3441"
GOLD = "#C9A227"
UP = "#4FA97E"
DOWN = "#C15C4A"
TEXT = "#E7E3D8"
TEXT_DIM = "#8B95A6"

st.markdown(f"""
<style>
    .stApp {{ background-color: {INK}; color: {TEXT}; }}
    section[data-testid="stSidebar"] {{ background-color: {PANEL}; border-right: 1px solid {LINE}; }}
    h1, h2, h3 {{ font-family: Georgia, 'Times New Roman', serif; font-weight: 500; }}
    .stMetric {{ background-color: {PANEL}; border: 1px solid {LINE}; border-radius: 4px; padding: 0.6rem 0.8rem; }}
    div[data-testid="stMetricValue"] {{ color: {GOLD}; font-family: 'Courier New', monospace; }}
    .stButton>button {{
        background-color: {GOLD}; color: #15100A; border: none; font-weight: 600;
    }}
    .stButton>button:hover {{ background-color: #E0B830; color: #15100A; }}
    code, .stCode {{ color: {TEXT_DIM}; }}
    hr {{ border-color: {LINE}; }}
</style>
""", unsafe_allow_html=True)


def make_line_fig(x, ys: dict, title: str, dash: dict | None = None, height: int = 320) -> go.Figure:
    """ys: {series_name: (values, color)}"""
    fig = go.Figure()
    dash = dash or {}
    for name, (values, color) in ys.items():
        fig.add_trace(go.Scatter(
            x=x, y=values, mode="lines", name=name,
            line=dict(color=color, width=2, dash=dash.get(name, "solid")),
        ))
    fig.update_layout(
        title=title, height=height, template="plotly_dark",
        paper_bgcolor=PANEL, plot_bgcolor=PANEL,
        font=dict(color=TEXT_DIM, family="Courier New, monospace", size=11),
        margin=dict(l=40, r=20, t=40, b=30),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
        xaxis=dict(gridcolor=LINE), yaxis=dict(gridcolor=LINE),
    )
    return fig


# --------------------------------------------------------------------------
# Session state
# --------------------------------------------------------------------------

defaults = {
    "df": None, "series_label": "", "model": None, "device": torch.device("cpu"),
    "lookback": 20, "vmin": 0.0, "vmax": 1.0, "loss_history": [],
    "test_dates": None, "test_actual": None, "test_pred": None, "metrics": None,
    "trained": False,
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v


def load_sample():
    st.session_state.df = lb.generate_synthetic_series(500)
    st.session_state.series_label = "Sample · synthetic walk · 500 sessions"
    st.session_state.trained = False


if st.session_state.df is None:
    load_sample()


# --------------------------------------------------------------------------
# Sidebar — data + model controls
# --------------------------------------------------------------------------

st.sidebar.markdown("## Data")
source = st.sidebar.radio("Source", ["Sample walk", "Upload CSV", "Ticker (yfinance)"], label_visibility="collapsed")

if source == "Sample walk":
    if st.sidebar.button("Regenerate sample"):
        load_sample()
elif source == "Upload CSV":
    uploaded = st.sidebar.file_uploader("CSV with Date + Close columns", type=["csv"])
    if uploaded is not None:
        try:
            df = lb.load_from_csv(uploaded)
            if len(df) < 30:
                st.sidebar.error("Found fewer than 30 valid rows in that file.")
            else:
                st.session_state.df = df
                st.session_state.series_label = f"Uploaded · {uploaded.name} · {len(df)} rows"
                st.session_state.trained = False
        except Exception as e:
            st.sidebar.error(str(e))
else:
    ticker = st.sidebar.text_input("Ticker symbol", value="AAPL")
    period = st.sidebar.selectbox("Period", ["1y", "2y", "3y", "5y", "10y"], index=2)
    if st.sidebar.button("Download"):
        try:
            with st.sidebar.status(f"Fetching {ticker}..."):
                df = lb.load_from_yfinance(ticker, period)
            st.session_state.df = df
            st.session_state.series_label = f"{ticker.upper()} · Yahoo Finance · {period}"
            st.session_state.trained = False
        except Exception as e:
            st.sidebar.error(f"Couldn't fetch {ticker}: {e}")

st.sidebar.markdown("## Model")
model_type = st.sidebar.radio("Cell type", ["lstm", "gru"], format_func=str.upper, horizontal=True)
lookback = st.sidebar.slider("Lookback window", 5, 60, 20)
hidden_size = st.sidebar.slider("Hidden units", 8, 128, 32, step=8)
num_layers = st.sidebar.slider("Stacked layers", 1, 3, 1)
epochs = st.sidebar.slider("Epochs", 5, 150, 30, step=5)
train_split = st.sidebar.slider("Train / test split", 60, 90, 80, step=5)
lr = st.sidebar.select_slider("Learning rate", options=[0.001, 0.003, 0.01, 0.03], value=0.01)

train_clicked = st.sidebar.button("Train model", type="primary", use_container_width=True)

st.sidebar.markdown("---")
st.sidebar.caption(
    "Educational tool. A recurrent net trained on closing prices alone, with "
    "no fundamentals or macro data, is not a trading signal."
)


# --------------------------------------------------------------------------
# Header + price chart
# --------------------------------------------------------------------------

st.markdown("# look**back**")
st.caption("LSTM & GRU sequence models, trained live in this app.")

df = st.session_state.df
last_price = df["Close"].iloc[-1]
first_price = df["Close"].iloc[0]
chg = (last_price - first_price) / first_price * 100

c1, c2, c3 = st.columns([3, 1, 1])
c1.markdown(f"**{st.session_state.series_label}**")
c2.metric("Last close", f"{last_price:.2f}")
c3.metric("Since start", f"{chg:+.1f}%")

st.plotly_chart(
    make_line_fig(df.index, {"Close": (df["Close"], GOLD)}, "Price history", height=280),
    use_container_width=True,
)


# --------------------------------------------------------------------------
# Training
# --------------------------------------------------------------------------

if train_clicked:
    closes = df["Close"].to_numpy(dtype=float)
    min_needed = lookback + 30
    if len(closes) < min_needed:
        st.error(f"Need at least {min_needed} data points for a lookback of {lookback}; this series has {len(closes)}.")
    else:
        vmin, vmax = lb.minmax_fit(closes)
        norm = lb.minmax_transform(closes, vmin, vmax)
        X, y = lb.make_sequences(norm, lookback)
        split_idx = int(len(X) * (train_split / 100))
        X_train, y_train = X[:split_idx], y[:split_idx]
        X_test, y_test = X[split_idx:], y[split_idx:]

        if len(X_train) < 10 or len(X_test) < 5:
            st.error("Not enough sequences for this split / lookback combination. Try a shorter lookback.")
        else:
            st.markdown("### Training")
            progress = st.progress(0, text="Starting…")
            loss_chart_slot = st.empty()
            loss_history = []

            def on_epoch_end(epoch, total_epochs, loss):
                loss_history.append(loss)
                progress.progress(epoch / total_epochs, text=f"Epoch {epoch}/{total_epochs} · loss {loss:.5f}")
                if epoch == 1 or epoch % max(1, total_epochs // 15) == 0 or epoch == total_epochs:
                    loss_chart_slot.plotly_chart(
                        make_line_fig(list(range(1, len(loss_history) + 1)),
                                      {"loss": (loss_history, GOLD)}, "Training loss (MSE, scaled)", height=220),
                        use_container_width=True,
                    )

            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            model = lb.SequenceRegressor(model_type, hidden_size, num_layers)
            t0 = time.time()
            lb.train_model(model, X_train, y_train, epochs, batch_size=16, lr=lr,
                            device=device, on_epoch_end=on_epoch_end)
            elapsed = time.time() - t0

            pred_norm = lb.predict(model, X_test, device)
            test_actual = lb.minmax_inverse(y_test, vmin, vmax)
            test_pred = lb.minmax_inverse(pred_norm, vmin, vmax)
            prev_actual = lb.minmax_inverse(X_test[:, -1], vmin, vmax)
            metrics = lb.compute_metrics(test_actual, test_pred, prev_actual)
            test_dates = df.index[lookback + split_idx: lookback + split_idx + len(test_actual)]

            st.session_state.update(dict(
                model=model, device=device, lookback=lookback, vmin=vmin, vmax=vmax,
                loss_history=loss_history, test_dates=test_dates, test_actual=test_actual,
                test_pred=test_pred, metrics=metrics, trained=True,
            ))
            st.success(f"Trained {model_type.upper()} in {elapsed:.1f}s on {len(X_train)} sequences, "
                       f"tested on {len(X_test)}.")


# --------------------------------------------------------------------------
# Results
# --------------------------------------------------------------------------

if st.session_state.trained:
    st.markdown("### Held-out predictions")
    st.plotly_chart(
        make_line_fig(
            st.session_state.test_dates,
            {"Actual": (st.session_state.test_actual, TEXT_DIM),
             "Predicted": (st.session_state.test_pred, GOLD)},
            "Test window, never seen during training",
        ),
        use_container_width=True,
    )

    m = st.session_state.metrics
    mc1, mc2, mc3, mc4 = st.columns(4)
    mc1.metric("RMSE", f"{m['rmse']:.2f}")
    mc2.metric("Mean abs. error", f"{m['mae']:.2f}")
    mc3.metric("Mean abs. % error", f"{m['mape']:.1f}%")
    mc4.metric("Directional accuracy", f"{m['directional_accuracy']:.0f}%")

    st.markdown("### Forward projection")
    steps = st.slider("Sessions ahead", 3, 30, 10)
    if st.button("Project forward"):
        closes = df["Close"].to_numpy(dtype=float)
        norm = lb.minmax_transform(closes, st.session_state.vmin, st.session_state.vmax)
        last_window = norm[-st.session_state.lookback:]
        future_norm = lb.forecast_forward(st.session_state.model, last_window, steps, st.session_state.device)
        future_pred = lb.minmax_inverse(future_norm, st.session_state.vmin, st.session_state.vmax)
        future_dates = pd.bdate_range(start=df.index[-1], periods=steps + 1)[1:]

        tail = df.tail(60)
        bridge_dates = [tail.index[-1]] + list(future_dates)
        bridge_vals = [tail["Close"].iloc[-1]] + list(future_pred)

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=tail.index, y=tail["Close"], mode="lines", name="Actual",
                                  line=dict(color=TEXT_DIM, width=2)))
        fig.add_trace(go.Scatter(x=bridge_dates, y=bridge_vals, mode="lines", name="Forecast",
                                  line=dict(color=GOLD, width=2, dash="dash")))
        fig.update_layout(
            title="Recursive forecast — each step feeds the next", height=320, template="plotly_dark",
            paper_bgcolor=PANEL, plot_bgcolor=PANEL,
            font=dict(color=TEXT_DIM, family="Courier New, monospace", size=11),
            margin=dict(l=40, r=20, t=40, b=30),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
            xaxis=dict(gridcolor=LINE), yaxis=dict(gridcolor=LINE),
        )
        st.plotly_chart(fig, use_container_width=True)

        end_chg = (future_pred[-1] - closes[-1]) / closes[-1] * 100
        st.caption(f"{steps} sessions ahead → {future_pred[-1]:.2f} ({end_chg:+.1f}%)")
else:
    st.info("Train a model above to see held-out predictions and a forward projection.")

st.markdown("---")
st.caption(
    "Lookback is an educational tool. Recurrent models trained on a few hundred closing "
    "prices, with no fundamental or macro data, do not reliably predict markets. "
    "Nothing here is investment advice."
)
