# Lookback — the website, in Python

A Streamlit app that reproduces the browser version: pick LSTM or GRU,
load data (a synthetic walk, your own CSV, or a live ticker via
yfinance), train in the browser tab it opens for you, and see held-out
predictions plus a forward projection — all running as real Python/PyTorch
underneath instead of TensorFlow.js.

## Files

- `app.py` — the Streamlit website itself.
- `lookback_core.py` — data loading, the LSTM/GRU model, training,
  metrics, and forecasting. Plain Python/PyTorch, no Streamlit
  dependency, so you can also `import lookback_core` from a notebook.

## Setup

```bash
pip install -r requirements_web.txt
```

## Run it

```bash
streamlit run app.py
```

This opens a local website (by default at `http://localhost:8501`) with:

- A sidebar to choose the data source (sample walk / CSV upload / ticker),
  the model type, and hyperparameters (lookback window, hidden units,
  stacked layers, epochs, train/test split, learning rate).
- A live-updating loss chart and progress bar while training runs.
- Held-out predictions vs. actuals, with RMSE / MAE / MAPE / directional
  accuracy.
- A forward projection you can re-run with a different horizon without
  retraining the model.

## Deploying it as a real, hosted website

Streamlit apps deploy as-is to [Streamlit Community Cloud](https://streamlit.io/cloud)
(point it at a GitHub repo containing `app.py` and `requirements_web.txt`),
or you can containerize it and run `streamlit run app.py --server.port $PORT`
behind any host that supports long-running processes (training happens
synchronously in the request, so a small VM or container works better here
than a serverless function).

## Honest limitations

Same as the script version: a single-feature model trained on closing
prices alone. Watch directional accuracy — near 50% means the model isn't
finding real structure, just riding momentum. Not investment advice.
